import django from '../../../assets/framworkIcon/Django.png'
import flask from '../../../assets/framworkIcon/grafana.png'
import fast from '../../../assets/framworkIcon/kafka.png'

const PythonFramworks = () => {
    return (
        <div className='mx-auto'>
            <div class="flex flex-row space-x-4 ">
                <div class="basis-1/5 flex-initial border border-black rounded ">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>Django</h1>
                </div>
                <div class="basis-1/5 flex-initial border border-black rounded">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>Flask</h1>
                </div>
                <div class="basis-1/5 flex-initial border border-black rounded">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>Fast API</h1>
                </div>
                <div class="basis-1/5 flex-initial border border-black rounded w-50 h-50">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>Kafka</h1>
                </div>
                <div class="basis-1/5 flex-initial border border-black rounded">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>Grafana</h1>
                </div>
               
               
            </div>
        </div>
    )
}

export default PythonFramworks;