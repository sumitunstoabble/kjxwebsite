import django from '../../../assets/framworkIcon/Django.png'
import flask from '../../../assets/framworkIcon/grafana.png'
import fast from '../../../assets/framworkIcon/kafka.png'

const MVC = () => {
    return (
        <div className='mx-auto'>
            <div class="flex flex-row space-x-4 ">
                <div class="basis-1/5 flex-initial border border-black rounded ">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>React JS </h1>
                </div>
                <div class="basis-1/5 flex-initial border border-black rounded">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>Vue JS </h1>
                </div>
                <div class="basis-1/5 flex-initial border border-black rounded">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>Angular JS </h1>
                </div>
                <div class="basis-1/5 flex-initial border border-black rounded w-50 h-50">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>Node JS </h1>
                </div>
                <div class="basis-1/5 flex-initial border border-black rounded">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>Grafana </h1>
                </div>
               
               
            </div>
        </div>
    )
}

export default MVC;