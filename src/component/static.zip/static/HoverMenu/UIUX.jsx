import django from '../../../assets/framworkIcon/Django.png'
import flask from '../../../assets/framworkIcon/grafana.png'
import fast from '../../../assets/framworkIcon/kafka.png'

const UIUX = () => {
    return (
        <div className='mx-auto'>
            <div class="flex flex-row space-x-4 ">
                <div class="basis-1/5 flex-initial border border-black rounded ">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>PSD to HTML</h1>
                </div>
                <div class="basis-1/5 flex-initial border border-black rounded">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>Responsive web</h1>
                </div>
                <div class="basis-1/5 flex-initial border border-black rounded">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>Mobile App</h1>
                </div>
                <div class="basis-1/5 flex-initial border border-black rounded w-50 h-50">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>Prototype </h1>
                </div>
             
               
               
            </div>
        </div>
    )
}

export default UIUX;