import django from '../../../assets/framworkIcon/Django.png'
import flask from '../../../assets/framworkIcon/grafana.png'
import fast from '../../../assets/framworkIcon/kafka.png'

const PHP = () => {
    return (
        <div className='mx-auto'>
            <div class="flex flex-row space-x-4 ">
                <div class="basis-1/5 flex-initial border border-black rounded ">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>Laravel </h1>
                </div>
                <div class="basis-1/5 flex-initial border border-black rounded">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>CakePHP</h1>
                </div>
                <div class="basis-1/5 flex-initial border border-black rounded">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>CodeIgniter</h1>
                </div>
                <div class="basis-1/5 flex-initial border border-black rounded w-50 h-50">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>Wordpress </h1>
                </div>
                <div class="basis-1/5 flex-initial border border-black rounded">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>Shopify </h1>
                </div>
               
               
            </div>
        </div>
    )
}

export default PHP;