import django from '../../../assets/framworkIcon/Django.png'
import flask from '../../../assets/framworkIcon/grafana.png'
import fast from '../../../assets/framworkIcon/kafka.png'

const API = () => {
    return (
        <div className='mx-auto'>
            <div class="flex flex-row space-x-4 ">
                <div class="basis-1/5 flex-initial border border-black rounded ">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>Payment API </h1>
                </div>
                <div class="basis-1/5 flex-initial border border-black rounded">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>Shipping API</h1>
                </div>
                <div class="basis-1/5 flex-initial border border-black rounded">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>Authentication API</h1>
                </div>
                <div class="basis-1/5 flex-initial border border-black rounded w-50 h-50">
                    <h1 className='text-center p-8 text-4xl w-50 h-50'>Phone Verification API </h1>
                </div>
               
               
               
            </div>
        </div>
    )
}

export default API;