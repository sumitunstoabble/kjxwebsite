import React from 'react';
import '../../App.css';
import PythonFramworks from './HoverMenu/PythonFramworks';
import MVC from './HoverMenu/mvc';
import PHP from './HoverMenu/php';
import UIUX from './HoverMenu/UIUX';
import API from './HoverMenu/API';

const Hover1 = () => {
    return (


        <div className="container">
            <div className="topic">ALL SERVICES</div>
            <div className="content">
                <input type="radio" name="slider" defaultChecked="" id="home" />
                <input type="radio" name="slider" id="blog" />
                <input type="radio" name="slider" id="help" />
                <input type="radio" name="slider" id="code" />
                <input type="radio" name="slider" id="about" />
                <input type="radio" name="slider" id="AI" />
                <input type="radio" name="slider" id="Mobile" />
                <div className="list">
                    <label htmlFor="home" className="home">
                        <span>Python Frameworks</span>
                    </label>
                    <label htmlFor="blog" className="blog">
                        <span>MVC Frameworks</span>
                    </label>
                    <label htmlFor="help" className="help">
                        <span>PHP Frameworks </span>
                    </label>
                    <label htmlFor="code" className="code">
                        <span>UI/UX Design </span>
                    </label>
                    <label htmlFor="about" className="about">
                        <span>API Integration</span>
                    </label>
                    <label htmlFor="AI" className="AI">
                        <span>AI/ ML </span>
                    </label>
                    <label htmlFor="Mobile" className="Mobile">
                        <span>Mobile Applications</span>
                    </label>
                    <div className="slider" />
                </div>
                <div className="text-content">
                    <div className="home text">
                        
                        <PythonFramworks />
                        
                        
                    </div>
                    <div className="blog text mx-auto">
                       
                        <MVC />
                    </div>
                    <div className="help text">
                       <PHP />
                    </div>
                    <div className="code text">
                       <UIUX />
                    </div>
                    <div className="about text">
                       <API />
                    </div>
                    <div className="AI text">
                       <API />
                    </div>
                    <div className="Mobile text">
                       <API />
                    </div>
                </div>
            </div>
        </div>


    );
}

export default Hover1;