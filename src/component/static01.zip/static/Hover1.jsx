import React from 'react';
import '../../App.css';
import PythonFramworks from './HoverMenu/PythonFramworks';
import MVC from './HoverMenu/mvc';
import PHP from './HoverMenu/php';
import UIUX from './HoverMenu/UIUX';
import API from './HoverMenu/API';
import AI from './HoverMenu/Ai';
import Mobile from './HoverMenu/mobile';

const Hover1 = ({ setIsOpens }) => {
    return (


        <div className="container bg-slate-300">
            <div className="topic">ALL SERVICES</div>
            <div className="content">
                <input type="radio" name="slider" defaultChecked="" id="home" />
                <input type="radio" name="slider" id="blog" />
                <input type="radio" name="slider" id="help" />
                <input type="radio" name="slider" id="code" />
                <input type="radio" name="slider" id="about" />
                <input type="radio" name="slider" id="artificial" />
                <input type="radio" name="slider" id="mobile" />
                <div className="list">
                    <label htmlFor="home" className="home">
                        <span>Python Frameworks</span>
                    </label>
                    <label htmlFor="blog" className="blog">
                        <span>MVC Frameworks</span>
                    </label>
                    <label htmlFor="help" className="help">
                        <span>PHP Frameworks </span>
                    </label>
                    <label htmlFor="code" className="code">
                        <span>UI/UX Design </span>
                    </label>
                    <label htmlFor="about" className="about">
                        <span>API Integration</span>
                    </label>
                    <label htmlFor="artificial" className="artificial">
                        <span>AI / ML </span>
                    </label>
                    <label htmlFor="mobile" className="mobile">
                        <span>Mobile Applications</span>
                    </label>
                    <div className="slider" />
                </div>
                <div className="text-content">
                    <div className="home text">
                        <PythonFramworks setIsOpens={setIsOpens} />
                    </div>
                    <div className="blog text mx-auto">
                        <MVC setIsOpens={setIsOpens}/>
                    </div>
                    <div className="help text">
                        <PHP setIsOpens={setIsOpens}/>
                    </div>
                    <div className="code text">
                        <UIUX setIsOpens={setIsOpens}/>
                    </div>
                    <div className="about text">
                        <API setIsOpens={setIsOpens}/>
                    </div>
                    <div className="artificial text">
                        <AI setIsOpens={setIsOpens}/>
                    </div>
                    <div className="mobile text">
                        <Mobile setIsOpens={setIsOpens}/>
                    </div>
                </div>
            </div>
        </div>


    );
}

export default Hover1;