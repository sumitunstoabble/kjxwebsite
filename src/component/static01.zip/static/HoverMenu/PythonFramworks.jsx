import React from "react";
import { Link } from "react-router-dom"


const PythonFramworks = ({ setIsOpens }) => {

    return (
        <div className='mx-auto'>
            <div class="flex flex-row space-x-4 ">
                <div class="basis-1/3 flex-initial border border-black rounded w-64 text-sky-900"  >
                    <h1 className='text-center p-8 text-4xl w-50 text-sky-900'>
                        <Link to={"/services/django-development"} onClick={() => setIsOpens(false)}> Django</Link>

                    </h1>
                </div>
                <div class="basis-1/3 flex-initial border border-black rounded w-64 text-sky-900">
                    <Link to={"/services/python-frameworks/flask"} onClick={() => setIsOpens(false)}>
                        <h1 className='text-center p-8 text-4xl w-50 text-sky-900'>Flask</h1>
                    </Link>
                </div>
                <div class="basis-1/3 flex-initial border border-black rounded w-64 text-sky-900">
                    <Link to={"/services/python-frameworks/fastapi"} onClick={() => setIsOpens(false)}>
                        <h1 className='text-center p-8 text-4xl w-50 text-sky-900'>Fast API</h1>
                    </Link>
                </div>
            </div>
            <div class="flex flex-row space-x-4 mt-10">
                <div class="basis-1/2 flex-initial border border-black rounded w-64 text-sky-900">
                    <Link to={"/services/python-frameworks/kafka"} onClick={() => setIsOpens(false)}>
                        <h1 className='text-center p-8 text-4xl w-50 text-sky-900'>Kafka</h1>
                    </Link>
                </div>
                <div class="basis-1/2 flex-initial border border-black rounded w-64 text-sky-900">
                    <Link to={"/services/python-frameworks/grafana"} onClick={() => setIsOpens(false)}>
                        <h1 className='text-center p-8 text-4xl w-50 text-sky-900'>Grafana</h1>
                    </Link>
                </div>
            </div>

        </div>
    )
}

export default PythonFramworks;